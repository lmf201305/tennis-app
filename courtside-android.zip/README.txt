Courtside (Android)

Standard Jetpack Compose app. Build with:  gradle assembleDebug
APK output: app/build/outputs/apk/debug/app-debug.apk

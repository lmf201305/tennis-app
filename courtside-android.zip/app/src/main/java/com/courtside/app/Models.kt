package com.courtside.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// MARK: - MODELS

enum class Player {
    YOU, OPPONENT;

    val other: Player get() = if (this == YOU) OPPONENT else YOU
    val index: Int get() = ordinal
}

enum class PointType(val title: String, val short: String) {
    WINNER("Winner", "Winner"),
    FORCED_ERROR("Forced error", "Forced"),
    UNFORCED_ERROR("Unforced error", "Unforced"),
    ACE("Ace", "Ace"),
    DOUBLE_FAULT("Double fault", "Double")
}

data class PointEvent(
    val id: String = UUID.randomUUID().toString(),
    val player: Player,
    val type: PointType,
    val timestamp: Long = System.currentTimeMillis()
) {
    val pointWinner: Player
        get() = when (type) {
            PointType.WINNER, PointType.ACE -> player
            else -> player.other
        }
}

data class MatchConfig(
    val playerOne: String,
    val playerTwo: String,
    val bestOf: Int,
    val firstServer: Player,
    val matchDate: Long,
    val decidingTiebreak: Boolean,
    val decidingTiebreakLength: Int
)

data class TennisMatch(
    val id: String = UUID.randomUUID().toString(),
    val config: MatchConfig,
    val events: List<PointEvent> = emptyList(),
    val startedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val isPaused: Boolean = false,
    val pausedAt: Long? = null,
    val totalPausedMs: Long = 0L,
    val endsSwapped: Boolean = false,
    val isAbandoned: Boolean = false
) {
    val isCompleted: Boolean
        get() = isAbandoned || MatchEngine.state(this).winner != null

    fun duration(now: Long): Long {
        val end = pausedAt ?: completedAt ?: now
        return maxOf(0L, end - startedAt - totalPausedMs)
    }
}

// MARK: - MATCH STATE

class MatchState {
    var games = intArrayOf(0, 0)
    var points = intArrayOf(0, 0)
    var tiebreakPoints = intArrayOf(0, 0)
    val completedSets = mutableListOf<IntArray>()
    var setsWon = intArrayOf(0, 0)
    var gameServer = Player.YOU
    var tiebreakFirstServer = Player.YOU
    var isTiebreak = false
    var winner: Player? = null
    var totalPoints = intArrayOf(0, 0)

    val currentSetNumber: Int get() = completedSets.size + 1

    val gameScore: String
        get() {
            if (isTiebreak) return "${tiebreakPoints[0]} – ${tiebreakPoints[1]}"

            if (points[0] >= 3 && points[1] >= 3) {
                if (points[0] == points[1]) return "Deuce"
                return if (points[0] > points[1]) "Advantage You" else "Advantage Opponent"
            }

            val names = listOf("0", "15", "30", "40")
            return "${names[minOf(points[0], 3)]} – ${names[minOf(points[1], 3)]}"
        }

    fun server(pointNumber: Int): Player {
        if (!isTiebreak) return gameServer
        if (pointNumber == 0) return tiebreakFirstServer

        val block = (pointNumber - 1) / 2
        return if (block % 2 == 0) tiebreakFirstServer.other else tiebreakFirstServer
    }
}

data class Activity(
    val id: String,
    val title: String,
    val detail: String,
    val timestamp: Long
)

data class PlayerStats(
    var winners: Int = 0,
    var forcedErrors: Int = 0,
    var unforcedErrors: Int = 0,
    var aces: Int = 0,
    var doubleFaults: Int = 0,
    var pointsWon: Int = 0,
    var gamesWon: Int = 0,
    var setsWon: Int = 0
)

// MARK: - SCORING ENGINE

object MatchEngine {

    fun state(match: TennisMatch): MatchState {
        val s = MatchState()
        s.gameServer = match.config.firstServer

        val setsRequired = match.config.bestOf / 2 + 1

        for (event in match.events) {
            if (s.winner != null) break

            val scorer = event.pointWinner
            val i = scorer.index
            val o = 1 - i

            s.totalPoints[i] = s.totalPoints[i] + 1

            if (s.isTiebreak) {
                s.tiebreakPoints[i] = s.tiebreakPoints[i] + 1

                val isDecidingSet = s.currentSetNumber == setsRequired * 2 - 1
                val target =
                    if (isDecidingSet && match.config.decidingTiebreak) match.config.decidingTiebreakLength
                    else 7

                if (s.tiebreakPoints[i] >= target && s.tiebreakPoints[i] - s.tiebreakPoints[o] >= 2) {
                    s.games[i] = s.games[i] + 1
                    finishSet(scorer, s, setsRequired)

                    if (s.winner == null) {
                        s.gameServer = s.tiebreakFirstServer.other
                    }
                }
            } else {
                s.points[i] = s.points[i] + 1

                if (s.points[i] >= 4 && s.points[i] - s.points[o] >= 2) {
                    s.games[i] = s.games[i] + 1
                    s.points = intArrayOf(0, 0)
                    s.gameServer = s.gameServer.other

                    if (s.games[0] == 6 && s.games[1] == 6) {
                        s.isTiebreak = true
                        s.tiebreakFirstServer = s.gameServer
                    } else if (s.games[i] >= 6 && s.games[i] - s.games[o] >= 2) {
                        finishSet(scorer, s, setsRequired)
                    }
                }
            }
        }

        return s
    }

    private fun finishSet(winner: Player, s: MatchState, setsRequired: Int) {
        s.completedSets.add(s.games.copyOf())
        s.setsWon[winner.index] = s.setsWon[winner.index] + 1

        s.games = intArrayOf(0, 0)
        s.points = intArrayOf(0, 0)
        s.tiebreakPoints = intArrayOf(0, 0)
        s.isTiebreak = false

        if (s.setsWon[winner.index] >= setsRequired) {
            s.winner = winner
        }
    }

    fun record(match: TennisMatch, type: PointType, by: Player): TennisMatch {
        if (match.isCompleted || match.isPaused) return match

        val st = state(match)
        val pointNumber = st.tiebreakPoints[0] + st.tiebreakPoints[1]
        val server = st.server(pointNumber)

        if ((type == PointType.ACE || type == PointType.DOUBLE_FAULT) && server != by) {
            return match
        }

        val updated = match.copy(events = match.events + PointEvent(player = by, type = type))

        return if (state(updated).winner != null) {
            updated.copy(completedAt = System.currentTimeMillis())
        } else {
            updated
        }
    }

    fun undo(match: TennisMatch): TennisMatch {
        if (match.events.isEmpty()) return match
        return match.copy(
            events = match.events.dropLast(1),
            completedAt = null,
            isAbandoned = false
        )
    }

    fun restart(match: TennisMatch): TennisMatch {
        return match.copy(
            events = emptyList(),
            startedAt = System.currentTimeMillis(),
            completedAt = null,
            isPaused = false,
            pausedAt = null,
            totalPausedMs = 0L,
            endsSwapped = false,
            isAbandoned = false
        )
    }

    fun pause(match: TennisMatch): TennisMatch {
        if (match.isPaused || match.isCompleted) return match
        return match.copy(isPaused = true, pausedAt = System.currentTimeMillis())
    }

    fun resume(match: TennisMatch): TennisMatch {
        if (!match.isPaused) return match

        val now = System.currentTimeMillis()
        val extra = match.pausedAt?.let { now - it } ?: 0L

        return match.copy(
            totalPausedMs = match.totalPausedMs + extra,
            pausedAt = null,
            isPaused = false
        )
    }

    fun end(match: TennisMatch): TennisMatch {
        val now = System.currentTimeMillis()
        val extra = match.pausedAt?.let { now - it } ?: 0L

        return match.copy(
            totalPausedMs = match.totalPausedMs + extra,
            isAbandoned = true,
            completedAt = now,
            isPaused = false,
            pausedAt = null
        )
    }

    fun playerName(player: Player, match: TennisMatch): String =
        if (player == Player.YOU) match.config.playerOne else match.config.playerTwo

    fun timeline(match: TennisMatch): List<Activity> {
        val list = mutableListOf<Activity>()

        for (index in match.events.indices) {
            val before = state(match.copy(events = match.events.take(index)))
            val after = state(match.copy(events = match.events.take(index + 1)))

            val event = match.events[index]
            val winnerName = playerName(event.pointWinner, match)

            list.add(
                Activity(
                    id = event.id,
                    title = "$winnerName won the point",
                    detail = "${event.type.title} · ${after.gameScore}",
                    timestamp = event.timestamp
                )
            )

            if (!before.isTiebreak && after.isTiebreak) {
                list.add(
                    Activity(
                        id = UUID.randomUUID().toString(),
                        title = "Tiebreak started",
                        detail = "Set ${after.currentSetNumber}",
                        timestamp = event.timestamp
                    )
                )
            }

            if (after.completedSets.size > before.completedSets.size) {
                val setScore = after.completedSets.last()
                val finalWinner = after.winner

                if (finalWinner != null) {
                    list.add(
                        Activity(
                            id = UUID.randomUUID().toString(),
                            title = "${playerName(finalWinner, match)} won the match",
                            detail = "Final set: ${setScore[0]} – ${setScore[1]}",
                            timestamp = event.timestamp
                        )
                    )
                } else {
                    val setWinner = if (after.setsWon[0] > before.setsWon[0]) Player.YOU else Player.OPPONENT

                    list.add(
                        Activity(
                            id = UUID.randomUUID().toString(),
                            title = "${playerName(setWinner, match)} won the set",
                            detail = "Set score: ${setScore[0]} – ${setScore[1]}",
                            timestamp = event.timestamp
                        )
                    )
                }
            } else if (after.games[0] + after.games[1] > before.games[0] + before.games[1]) {
                list.add(
                    Activity(
                        id = UUID.randomUUID().toString(),
                        title = "$winnerName won the game",
                        detail = "Game completed",
                        timestamp = event.timestamp
                    )
                )
            }
        }

        if (match.isAbandoned) {
            list.add(
                Activity(
                    id = UUID.randomUUID().toString(),
                    title = "Match ended",
                    detail = "Match ended before a winner was decided.",
                    timestamp = match.completedAt ?: System.currentTimeMillis()
                )
            )
        }

        return list.sortedByDescending { it.timestamp }
    }

    fun stats(player: Player, match: TennisMatch): PlayerStats {
        val r = PlayerStats()

        for (event in match.events) {
            if (event.player == player) {
                when (event.type) {
                    PointType.WINNER -> r.winners++
                    PointType.FORCED_ERROR -> r.forcedErrors++
                    PointType.UNFORCED_ERROR -> r.unforcedErrors++
                    PointType.ACE -> r.aces++
                    PointType.DOUBLE_FAULT -> r.doubleFaults++
                }
            }

            if (event.pointWinner == player) {
                r.pointsWon++
            }
        }

        val s = state(match)
        r.gamesWon = s.completedSets.sumOf { it[player.index] } + s.games[player.index]
        r.setsWon = s.setsWon[player.index]

        return r
    }
}

// MARK: - STORAGE

object Store {

    private const val PREFS = "courtside"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun playerName(c: Context): String = prefs(c).getString("playerName", "") ?: ""

    fun setPlayerName(c: Context, name: String) {
        prefs(c).edit().putString("playerName", name).apply()
    }

    fun loadHistory(c: Context): List<TennisMatch> {
        return try {
            val raw = prefs(c).getString("history", "[]") ?: "[]"
            val arr = JSONArray(raw)
            (0 until arr.length()).map { matchFromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun loadActive(c: Context): TennisMatch? {
        return try {
            val raw = prefs(c).getString("active", null) ?: return null
            val match = matchFromJson(JSONObject(raw))
            if (match.isCompleted) null else match
        } catch (e: Exception) {
            null
        }
    }

    fun save(c: Context, history: List<TennisMatch>, active: TennisMatch?) {
        val arr = JSONArray()
        history.forEach { arr.put(matchToJson(it)) }

        val editor = prefs(c).edit()
        editor.putString("history", arr.toString())

        if (active != null) {
            editor.putString("active", matchToJson(active).toString())
        } else {
            editor.remove("active")
        }

        editor.apply()
    }

    private fun matchToJson(m: TennisMatch): JSONObject {
        val config = JSONObject()
        config.put("p1", m.config.playerOne)
        config.put("p2", m.config.playerTwo)
        config.put("bestOf", m.config.bestOf)
        config.put("server", m.config.firstServer.name)
        config.put("date", m.config.matchDate)
        config.put("dtb", m.config.decidingTiebreak)
        config.put("dtbLen", m.config.decidingTiebreakLength)

        val events = JSONArray()
        for (e in m.events) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("player", e.player.name)
            o.put("type", e.type.name)
            o.put("ts", e.timestamp)
            events.put(o)
        }

        val o = JSONObject()
        o.put("id", m.id)
        o.put("config", config)
        o.put("events", events)
        o.put("startedAt", m.startedAt)
        if (m.completedAt != null) o.put("completedAt", m.completedAt)
        o.put("isPaused", m.isPaused)
        if (m.pausedAt != null) o.put("pausedAt", m.pausedAt)
        o.put("totalPausedMs", m.totalPausedMs)
        o.put("endsSwapped", m.endsSwapped)
        o.put("isAbandoned", m.isAbandoned)
        return o
    }

    private fun matchFromJson(o: JSONObject): TennisMatch {
        val c = o.getJSONObject("config")

        val config = MatchConfig(
            playerOne = c.getString("p1"),
            playerTwo = c.getString("p2"),
            bestOf = c.getInt("bestOf"),
            firstServer = Player.valueOf(c.getString("server")),
            matchDate = c.getLong("date"),
            decidingTiebreak = c.getBoolean("dtb"),
            decidingTiebreakLength = c.getInt("dtbLen")
        )

        val ev = o.getJSONArray("events")
        val events = (0 until ev.length()).map {
            val e = ev.getJSONObject(it)
            PointEvent(
                id = e.getString("id"),
                player = Player.valueOf(e.getString("player")),
                type = PointType.valueOf(e.getString("type")),
                timestamp = e.getLong("ts")
            )
        }

        return TennisMatch(
            id = o.getString("id"),
            config = config,
            events = events,
            startedAt = o.getLong("startedAt"),
            completedAt = if (o.has("completedAt")) o.getLong("completedAt") else null,
            isPaused = o.getBoolean("isPaused"),
            pausedAt = if (o.has("pausedAt")) o.getLong("pausedAt") else null,
            totalPausedMs = o.getLong("totalPausedMs"),
            endsSwapped = o.getBoolean("endsSwapped"),
            isAbandoned = o.getBoolean("isAbandoned")
        )
    }
}

package com.courtside.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )

        setContent {
            CourtsideTheme {
                CourtsideApp()
            }
        }
    }
}

// MARK: - SHARED HELPERS

fun formatDuration(ms: Long): String {
    val s = maxOf(0L, ms / 1000)
    val h = s / 3600
    val m = (s % 3600) / 60
    val r = s % 60

    return if (h > 0) "%d:%02d:%02d".format(h, m, r) else "%02d:%02d".format(m, r)
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

@Composable
fun <T> Segmented(
    options: List<Pair<String, T>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CS.SurfaceLight)
            .padding(3.dp)
    ) {
        options.forEach { (label, value) ->
            val on = value == selected

            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (on) CS.Green else Color.Transparent)
                    .clickable { onSelect(value) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (on) Color.White else CS.Forest,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// MARK: - APP

private data class TabItem(val label: String, val icon: ImageVector)

@Composable
fun CourtsideApp() {
    val ctx = LocalContext.current

    var history by remember { mutableStateOf(Store.loadHistory(ctx)) }
    var active by remember { mutableStateOf(Store.loadActive(ctx)) }
    var showLive by remember { mutableStateOf(active != null) }
    var tab by remember { mutableIntStateOf(0) }
    var playerName by remember { mutableStateOf(Store.playerName(ctx)) }

    fun persist() {
        Store.save(ctx, history, active)
    }

    fun saveMatch(m: TennisMatch) {
        history = if (history.any { it.id == m.id }) {
            history.map { if (it.id == m.id) m else it }
        } else {
            history + m
        }
        persist()
    }

    val current = active

    if (showLive && current != null) {
        LiveMatchScreen(
            initial = current,
            onUpdate = { updated ->
                active = updated
                if (updated.isCompleted) saveMatch(updated)
                persist()
            },
            onBack = { updated ->
                if (updated.isCompleted) {
                    saveMatch(updated)
                    active = null
                } else {
                    active = updated
                }
                persist()
                showLive = false
            },
            onEnd = { ended ->
                saveMatch(ended)
                active = null
                persist()
                showLive = false
            }
        )
        return
    }

    val tabs = listOf(
        TabItem("Home", Icons.Filled.Home),
        TabItem("History", Icons.Filled.History),
        TabItem("New Match", Icons.Filled.AddCircle),
        TabItem("You", Icons.Filled.Person)
    )

    Scaffold(
        containerColor = CS.Background,
        bottomBar = {
            NavigationBar(containerColor = CS.Surface) {
                tabs.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CS.Indicator,
                            selectedIconColor = CS.Forest,
                            selectedTextColor = CS.Forest,
                            unselectedIconColor = CS.Muted,
                            unselectedTextColor = CS.Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .background(CS.Background)
                .padding(padding)
        ) {
            when (tab) {
                0 -> HomeScreen(
                    playerName = playerName,
                    hasActive = active != null,
                    history = history,
                    onResume = { showLive = true },
                    onNew = { tab = 2 },
                    onSeeAll = { tab = 1 }
                )

                1 -> HistoryScreen(
                    history = history,
                    onDelete = { m ->
                        history = history.filter { it.id != m.id }
                        persist()
                    }
                )

                2 -> SetupScreen(
                    playerName = playerName,
                    onStart = { config ->
                        active = TennisMatch(config = config)
                        persist()
                        showLive = true
                    }
                )

                else -> ProfileScreen(
                    playerName = playerName,
                    onNameChange = {
                        playerName = it
                        Store.setPlayerName(ctx, it)
                    },
                    history = history
                )
            }
        }
    }
}

// MARK: - HOME

@Composable
fun HomeScreen(
    playerName: String,
    hasActive: Boolean,
    history: List<TennisMatch>,
    onResume: () -> Unit,
    onNew: () -> Unit,
    onSeeAll: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "COURTSIDE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = CS.Green
            )
            Text("Welcome back,", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = CS.Forest)
            Text(
                if (playerName.isBlank()) "Player" else playerName,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = CS.Green
            )
        }

        if (hasActive) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CS.Forest)
                    .clickable { onResume() }
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "MATCH IN PROGRESS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Text("Resume match", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(
                        "Continue where you left off.",
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
                Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(CS.Green)
                .clickable { onNew() }
                .padding(22.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "NEW MATCH",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.75f)
                )
                Text("Ready to play?", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    "Set up a match and start scoring.",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
            Icon(Icons.Filled.AddCircle, null, tint = Color.White)
        }

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Recent matches",
                    Modifier.weight(1f),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = CS.Forest
                )
                TextButton(onClick = onSeeAll) { Text("See all", color = CS.Green) }
            }

            if (history.isEmpty()) {
                EmptyState("No matches yet", "Your completed matches will appear here.")
            } else {
                history.sortedByDescending { it.startedAt }.take(3).forEach { m ->
                    MatchRow(m, onDelete = null)
                }
            }
        }
    }
}

@Composable
fun EmptyState(title: String, message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(30.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = CS.Forest)
        Text(message, fontSize = 14.sp, color = CS.Muted)
    }
}

// MARK: - HISTORY

@Composable
fun HistoryScreen(history: List<TennisMatch>, onDelete: (TennisMatch) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "History",
            Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = CS.Forest
        )

        if (history.isEmpty()) {
            EmptyState("No match history", "Start a match to build your history.")
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 16.dp, end = 16.dp, top = 6.dp, bottom = 16.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(history.sortedByDescending { it.startedAt }, key = { it.id }) { m ->
                    MatchRow(m, onDelete = { onDelete(m) })
                }
            }
        }
    }
}

@Composable
fun MatchRow(match: TennisMatch, onDelete: (() -> Unit)?) {
    val state = remember(match) { MatchEngine.state(match) }

    val result = when {
        match.isAbandoned -> "Ended"
        state.winner == Player.YOU -> "Won"
        state.winner == Player.OPPONENT -> "Lost"
        else -> "In progress"
    }

    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(match.config.playerOne, fontWeight = FontWeight.SemiBold, color = CS.Forest)
                Text(match.config.playerTwo, fontWeight = FontWeight.SemiBold, color = CS.Muted)
            }

            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "${state.setsWon[0]} – ${state.setsWon[1]}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = CS.Forest
                )
                Text(
                    result,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (state.winner == Player.YOU) CS.Green else CS.Muted
                )
            }

            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, "Delete match", tint = CS.Muted)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Row {
            Text(formatDate(match.config.matchDate), Modifier.weight(1f), fontSize = 12.sp, color = CS.Muted)
            Text("${match.events.size} points", fontSize = 12.sp, color = CS.Muted)
        }
    }
}

// MARK: - SETUP

@Composable
fun SetupScreen(playerName: String, onStart: (MatchConfig) -> Unit) {
    var opponent by remember { mutableStateOf("") }
    var bestOf by remember { mutableIntStateOf(3) }
    var firstServer by remember { mutableStateOf(Player.YOU) }
    var decidingTiebreak by remember { mutableStateOf(false) }
    var tiebreakLength by remember { mutableIntStateOf(10) }

    val me = if (playerName.isBlank()) "You" else playerName.trim()
    val canStart = opponent.isNotBlank()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "MATCH SETUP",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = CS.Green
            )
            Text("New match", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = CS.Forest)
            Text(
                "Configure your match before stepping onto court.",
                fontSize = 14.sp,
                color = CS.Muted
            )
        }

        SetupSection("Players") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CS.SurfaceLight)
                    .padding(14.dp)
            ) {
                Column {
                    Text("You", fontSize = 12.sp, color = CS.Muted)
                    Text(me, fontWeight = FontWeight.SemiBold, color = CS.Forest)
                }
            }

            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = opponent,
                onValueChange = { opponent = it },
                label = { Text("Opponent's name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        SetupSection("Match format") {
            Text("Best of", fontWeight = FontWeight.Medium, color = CS.Forest)
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("1 set" to 1, "3 sets" to 3, "5 sets" to 5), bestOf, { bestOf = it })
        }

        SetupSection("Tiebreak") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Deciding-set tiebreak",
                    Modifier.weight(1f),
                    color = CS.Forest
                )
                Switch(
                    checked = decidingTiebreak,
                    onCheckedChange = { decidingTiebreak = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = CS.Green)
                )
            }

            if (decidingTiebreak) {
                Spacer(Modifier.height(8.dp))
                Segmented(
                    listOf("7 points" to 7, "10 points" to 10),
                    tiebreakLength,
                    { tiebreakLength = it }
                )
            }

            Spacer(Modifier.height(8.dp))
            Text("Regular sets use a 7-point tiebreak at 6–6.", fontSize = 12.sp, color = CS.Muted)
        }

        SetupSection("First server") {
            Segmented(
                listOf("You" to Player.YOU, "Opponent" to Player.OPPONENT),
                firstServer,
                { firstServer = it }
            )
        }

        Button(
            onClick = {
                onStart(
                    MatchConfig(
                        playerOne = me,
                        playerTwo = opponent.trim(),
                        bestOf = bestOf,
                        firstServer = firstServer,
                        matchDate = System.currentTimeMillis(),
                        decidingTiebreak = decidingTiebreak,
                        decidingTiebreakLength = tiebreakLength
                    )
                )
            },
            enabled = canStart,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CS.Green)
        ) {
            Text("Start Match", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SetupSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = CS.Forest)

        AppCard {
            content()
        }
    }
}

// MARK: - PROFILE

@Composable
fun ProfileScreen(
    playerName: String,
    onNameChange: (String) -> Unit,
    history: List<TennisMatch>
) {
    val wins = history.count { MatchEngine.state(it).winner == Player.YOU }
    val losses = history.count { MatchEngine.state(it).winner == Player.OPPONENT }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("You", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = CS.Forest)

        SetupSection("Player") {
            OutlinedTextField(
                value = playerName,
                onValueChange = onNameChange,
                label = { Text("Your name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        SetupSection("Statistics") {
            StatLine("Matches played", history.size.toString())
            StatLine("Wins", wins.toString())
            StatLine("Losses", losses.toString())
        }

        Text(
            "Your match history is saved on this device.",
            fontSize = 12.sp,
            color = CS.Muted
        )
    }
}

@Composable
fun StatLine(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Text(label, Modifier.weight(1f), color = CS.Forest)
        Text(value, fontWeight = FontWeight.SemiBold, color = CS.Forest)
    }
}

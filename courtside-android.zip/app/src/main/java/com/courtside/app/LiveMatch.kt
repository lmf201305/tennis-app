package com.courtside.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private fun iconFor(type: PointType): ImageVector = when (type) {
    PointType.WINNER -> Icons.Filled.CheckCircle
    PointType.FORCED_ERROR -> Icons.Filled.Info
    PointType.UNFORCED_ERROR -> Icons.Filled.Close
    PointType.ACE -> Icons.Filled.Star
    PointType.DOUBLE_FAULT -> Icons.Filled.Warning
}

@Composable
fun LiveMatchScreen(
    initial: TennisMatch,
    onUpdate: (TennisMatch) -> Unit,
    onBack: (TennisMatch) -> Unit,
    onEnd: (TennisMatch) -> Unit
) {
    var match by remember(initial.id) { mutableStateOf(initial) }
    var panel by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var showOpponent by remember { mutableStateOf(false) }
    var showRestart by remember { mutableStateOf(false) }
    var showEnd by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }

    val state = remember(match) { MatchEngine.state(match) }
    val finished = state.winner != null || match.isAbandoned

    fun change(m: TennisMatch) {
        match = m
        onUpdate(m)
    }

    fun leave() {
        val m = if (finished) match else MatchEngine.pause(match)
        onBack(m)
    }

    BackHandler { leave() }

    Column(
        Modifier
            .fillMaxSize()
            .background(CS.Background)
            .systemBarsPadding()
    ) {
        if (finished) {
            CompletionContent(match = match, state = state, onHome = { onBack(match) })
        } else {
            // HEADER
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(CS.Surface)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { leave() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back to home", tint = CS.Forest)
                    }

                    val dot = if (match.isPaused) Color(0xFFE08A00) else Color(0xFFD32F2F)

                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(dot)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                if (match.isPaused) "PAUSED" else "LIVE",
                                color = dot,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                        }
                        Text(
                            formatDuration(match.duration(now)),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                            color = CS.Muted
                        )
                    }

                    TextButton(
                        onClick = { change(MatchEngine.undo(match)) },
                        enabled = match.events.isNotEmpty()
                    ) {
                        Text("Undo", color = if (match.events.isNotEmpty()) CS.Forest else CS.Muted)
                    }

                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, "More match options", tint = CS.Forest)
                        }

                        DropdownMenu(
                            expanded = menuOpen,
                            onDismissRequest = { menuOpen = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Match settings") },
                                onClick = { menuOpen = false; showSettings = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Edit opponent name") },
                                onClick = { menuOpen = false; showOpponent = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Change ends") },
                                onClick = {
                                    menuOpen = false
                                    change(match.copy(endsSwapped = !match.endsSwapped))
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (match.isPaused) "Resume match" else "Pause match") },
                                onClick = {
                                    menuOpen = false
                                    change(
                                        if (match.isPaused) MatchEngine.resume(match)
                                        else MatchEngine.pause(match)
                                    )
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Restart match", color = Color(0xFFD32F2F)) },
                                onClick = { menuOpen = false; showRestart = true }
                            )
                            DropdownMenuItem(
                                text = { Text("End match", color = Color(0xFFD32F2F)) },
                                onClick = { menuOpen = false; showEnd = true }
                            )
                        }
                    }
                }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    Text(
                        "BEST OF ${match.config.bestOf}",
                        Modifier.weight(1f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = CS.Muted
                    )
                    Text(
                        "SET ${state.currentSetNumber}" + if (state.isTiebreak) "  ·  TIEBREAK" else "",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = if (state.isTiebreak) CS.Green else CS.Muted
                    )
                }
            }

            // BODY
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 13.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Scoreboard(match, state)

                Segmented(
                    listOf("Score" to 0, "Stats" to 1, "Timeline" to 2),
                    panel,
                    { panel = it }
                )

                if (match.isPaused) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(13.dp))
                            .background(CS.Surface)
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Match paused",
                            Modifier.weight(1f),
                            fontWeight = FontWeight.SemiBold,
                            color = CS.Forest
                        )
                        TextButton(onClick = { change(MatchEngine.resume(match)) }) {
                            Text("Resume", color = CS.Green, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                when (panel) {
                    0 -> PointRecording(
                        match = match,
                        state = state,
                        onRecord = { type, player -> change(MatchEngine.record(match, type, player)) }
                    )

                    1 -> StatsPanel(match)
                    else -> TimelinePanel(match)
                }
            }
        }
    }

    // DIALOGS

    if (showRestart) {
        AlertDialog(
            onDismissRequest = { showRestart = false },
            containerColor = CS.Surface,
            title = { Text("Restart this match?") },
            text = { Text("All recorded points and match statistics will be cleared.") },
            confirmButton = {
                TextButton(onClick = {
                    showRestart = false
                    change(MatchEngine.restart(match))
                }) { Text("Restart", color = Color(0xFFD32F2F)) }
            },
            dismissButton = {
                TextButton(onClick = { showRestart = false }) { Text("Cancel") }
            }
        )
    }

    if (showEnd) {
        AlertDialog(
            onDismissRequest = { showEnd = false },
            containerColor = CS.Surface,
            title = { Text("End this match?") },
            text = { Text("The match will be marked as ended and saved to your history.") },
            confirmButton = {
                TextButton(onClick = {
                    showEnd = false
                    onEnd(MatchEngine.end(match))
                }) { Text("End match", color = Color(0xFFD32F2F)) }
            },
            dismissButton = {
                TextButton(onClick = { showEnd = false }) { Text("Cancel") }
            }
        )
    }

    if (showOpponent) {
        var text by remember { mutableStateOf(match.config.playerTwo) }

        AlertDialog(
            onDismissRequest = { showOpponent = false },
            containerColor = CS.Surface,
            title = { Text("Opponent name") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    label = { Text("Opponent's name") }
                )
            },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = {
                        showOpponent = false
                        change(match.copy(config = match.config.copy(playerTwo = text.trim())))
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showOpponent = false }) { Text("Cancel") }
            }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            containerColor = CS.Surface,
            title = { Text("Match settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Best of", fontWeight = FontWeight.Medium)
                    Segmented(
                        listOf("1 set" to 1, "3 sets" to 3, "5 sets" to 5),
                        match.config.bestOf,
                        { change(match.copy(config = match.config.copy(bestOf = it))) }
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Deciding-set tiebreak", Modifier.weight(1f))
                        Switch(
                            checked = match.config.decidingTiebreak,
                            onCheckedChange = {
                                change(match.copy(config = match.config.copy(decidingTiebreak = it)))
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = CS.Green)
                        )
                    }

                    if (match.config.decidingTiebreak) {
                        Segmented(
                            listOf("7 points" to 7, "10 points" to 10),
                            match.config.decidingTiebreakLength,
                            { change(match.copy(config = match.config.copy(decidingTiebreakLength = it))) }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSettings = false }) { Text("Done") }
            }
        )
    }
}

// MARK: - SCOREBOARD

private fun currentPoint(state: MatchState, i: Int): String {
    if (state.points[0] >= 3 && state.points[1] >= 3) {
        if (state.points[0] == state.points[1]) return "40"
        return if (state.points[i] > state.points[1 - i]) "AD" else "40"
    }
    return listOf("0", "15", "30", "40")[minOf(state.points[i], 3)]
}

@Composable
private fun Scoreboard(match: TennisMatch, state: MatchState) {
    val white = Color.White

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(17.dp))
            .background(CS.Green)
            .padding(horizontal = 15.dp, vertical = 12.dp)
    ) {
        Text(
            "MATCH SCORE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            color = white.copy(alpha = 0.75f)
        )
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            val h = white.copy(alpha = 0.6f)
            Text("PLAYER", Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = h)
            Text(
                "SETS", Modifier.width(38.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                color = h, textAlign = TextAlign.Center
            )
            state.completedSets.indices.forEach {
                Text(
                    "S${it + 1}", Modifier.width(32.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    color = h, textAlign = TextAlign.Center
                )
            }
            Text(
                if (state.isTiebreak) "TB" else "PTS", Modifier.width(47.dp), fontSize = 10.sp,
                fontWeight = FontWeight.Bold, color = h, textAlign = TextAlign.Center
            )
        }

        HorizontalDivider(Modifier.padding(top = 6.dp), color = white.copy(alpha = 0.18f))
        ScoreRow(if (match.endsSwapped) Player.OPPONENT else Player.YOU, match, state)
        HorizontalDivider(color = white.copy(alpha = 0.13f))
        ScoreRow(if (match.endsSwapped) Player.YOU else Player.OPPONENT, match, state)
        HorizontalDivider(color = white.copy(alpha = 0.18f))

        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (state.isTiebreak) "TIEBREAK" else "CURRENT GAME",
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, color = white.copy(alpha = 0.65f)
                )
                Text(state.gameScore, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = white)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    "TOTAL POINTS",
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, color = white.copy(alpha = 0.65f)
                )
                Text(
                    "${state.totalPoints[0] + state.totalPoints[1]}",
                    fontSize = 20.sp, fontWeight = FontWeight.Bold, color = white
                )
            }
        }
    }
}

@Composable
private fun ScoreRow(player: Player, match: TennisMatch, state: MatchState) {
    val i = player.index
    val pointNumber = state.tiebreakPoints[0] + state.tiebreakPoints[1]
    val serving = state.server(pointNumber) == player

    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            if (serving) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(CS.Fresh)
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(
                MatchEngine.playerName(player, match),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1
            )
        }

        Text(
            "${state.setsWon[i]}", Modifier.width(38.dp), fontSize = 16.sp,
            fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center
        )

        state.completedSets.forEach { set ->
            Text(
                "${set[i]}", Modifier.width(32.dp), fontSize = 14.sp,
                fontWeight = FontWeight.Bold, color = Color.White.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        }

        Text(
            if (state.isTiebreak) "${state.tiebreakPoints[i]}" else currentPoint(state, i),
            Modifier.width(47.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold,
            color = CS.Fresh, textAlign = TextAlign.Center
        )
    }
}

// MARK: - POINT RECORDING

@Composable
private fun PointRecording(
    match: TennisMatch,
    state: MatchState,
    onRecord: (PointType, Player) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Record point", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = CS.Forest)

        PlayerControls(Player.YOU, match, state, onRecord)
        PlayerControls(Player.OPPONENT, match, state, onRecord)

        Text(
            "Errors are recorded against the player who made them.",
            fontSize = 11.sp,
            color = CS.Muted
        )
    }
}

@Composable
private fun PlayerControls(
    player: Player,
    match: TennisMatch,
    state: MatchState,
    onRecord: (PointType, Player) -> Unit
) {
    val pointNumber = state.tiebreakPoints[0] + state.tiebreakPoints[1]
    val serving = state.server(pointNumber) == player

    val rows = listOf(
        listOf(PointType.WINNER, PointType.FORCED_ERROR, PointType.UNFORCED_ERROR),
        listOf(PointType.ACE, PointType.DOUBLE_FAULT)
    )

    AppCard(padding = 10.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                MatchEngine.playerName(player, match),
                fontWeight = FontWeight.Bold,
                color = CS.Forest,
                maxLines = 1
            )
            if (serving) {
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(CS.Green)
                )
                Spacer(Modifier.width(4.dp))
                Text("serving", fontSize = 11.sp, color = CS.Muted)
            }
        }

        Spacer(Modifier.height(8.dp))

        rows.forEach { rowTypes ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                rowTypes.forEach { type ->
                    val needsServe = type == PointType.ACE || type == PointType.DOUBLE_FAULT
                    val enabled = !match.isPaused && (!needsServe || serving)

                    PointButton(
                        type = type,
                        enabled = enabled,
                        modifier = Modifier.weight(1f),
                        onClick = { onRecord(type, player) }
                    )
                }

                if (rowTypes.size < 3) {
                    Spacer(Modifier.weight((3 - rowTypes.size).toFloat()))
                }
            }
        }
    }
}

@Composable
private fun PointButton(
    type: PointType,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val tint = if (enabled) CS.Green else Color(0xFFB5B5B5)

    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (enabled) CS.SurfaceLight else CS.Background)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(iconFor(type), null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(3.dp))
        Text(
            type.short,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (enabled) CS.Forest else Color(0xFFB5B5B5)
        )
    }
}

// MARK: - STATS

@Composable
private fun StatsPanel(match: TennisMatch) {
    val you = remember(match) { MatchEngine.stats(Player.YOU, match) }
    val opp = remember(match) { MatchEngine.stats(Player.OPPONENT, match) }

    AppCard {
        Text("Match statistics", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CS.Forest)
        Spacer(Modifier.height(10.dp))

        Row {
            Text(match.config.playerOne, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(match.config.playerTwo, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = CS.Border)

        StatCompare("Points won", you.pointsWon, opp.pointsWon)
        StatCompare("Winners", you.winners, opp.winners)
        StatCompare("Aces", you.aces, opp.aces)
        StatCompare("Forced errors", you.forcedErrors, opp.forcedErrors)
        StatCompare("Unforced errors", you.unforcedErrors, opp.unforcedErrors)
        StatCompare("Double faults", you.doubleFaults, opp.doubleFaults)
        StatCompare("Games won", you.gamesWon, opp.gamesWon)
        StatCompare("Sets won", you.setsWon, opp.setsWon)

        Spacer(Modifier.height(6.dp))
        Text("Statistics are calculated from recorded point events.", fontSize = 11.sp, color = CS.Muted)
    }
}

@Composable
private fun StatCompare(label: String, a: Int, b: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$a", Modifier.width(40.dp), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CS.Forest)
        Text(
            label, Modifier.weight(1f), fontSize = 14.sp, color = CS.Muted, textAlign = TextAlign.Center
        )
        Text(
            "$b", Modifier.width(40.dp), fontWeight = FontWeight.Bold, fontSize = 16.sp,
            color = CS.Forest, textAlign = TextAlign.End
        )
    }
}

// MARK: - TIMELINE

@Composable
private fun TimelinePanel(match: TennisMatch) {
    val activities = remember(match) { MatchEngine.timeline(match) }

    AppCard {
        Text("Match timeline", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CS.Forest)
        Spacer(Modifier.height(10.dp))

        if (activities.isEmpty()) {
            Text(
                "Match activity will appear here as points are recorded.",
                fontSize = 14.sp,
                color = CS.Muted
            )
        } else {
            activities.forEach { a ->
                Column(Modifier.padding(vertical = 6.dp)) {
                    Text(a.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = CS.Forest)
                    Text(a.detail, fontSize = 12.sp, color = CS.Muted)
                    Text(formatDate(a.timestamp), fontSize = 11.sp, color = CS.Muted)
                }
            }
        }
    }
}

// MARK: - COMPLETION

@Composable
private fun CompletionContent(match: TennisMatch, state: MatchState, onHome: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(20.dp))

        Text(
            if (match.isAbandoned) "Match ended" else "Match complete",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = CS.Forest
        )

        val winner = state.winner
        if (winner != null) {
            Text(
                MatchEngine.playerName(winner, match),
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = CS.Green
            )
            Text("WINNER", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = CS.Muted)
        } else {
            Text("No winner recorded", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = CS.Forest)
        }

        AppCard {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("FINAL SCORE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CS.Muted)
                Text(
                    "${state.setsWon[0]} – ${state.setsWon[1]}",
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    color = CS.Forest
                )
            }

            state.completedSets.forEachIndexed { i, set ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text("Set ${i + 1}", Modifier.weight(1f), color = CS.Forest)
                    Text("${set[0]} – ${set[1]}", fontWeight = FontWeight.SemiBold, color = CS.Forest)
                }
            }
        }

        Text(
            "Duration · ${formatDuration(match.duration(match.completedAt ?: System.currentTimeMillis()))}",
            fontSize = 14.sp,
            color = CS.Muted
        )

        StatsPanel(match)

        Text("Saved to history", fontSize = 13.sp, color = CS.Green, fontWeight = FontWeight.SemiBold)

        TextButton(onClick = onHome) {
            Text("Back to home", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = CS.Green)
        }
    }
}

package com.courtside.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object CS {
    val Forest = Color(0xFF2A3321)
    val Green = Color(0xFF335738)
    val Fresh = Color(0xFFADC292)
    val Background = Color(0xFFF5F0E3)
    val Surface = Color(0xFFFDFBF5)
    val SurfaceLight = Color(0xFFF0EBDB)
    val Border = Color(0xFFD6C9B0)
    val Indicator = Color(0xFFD5E4C5)
    val Muted = Color(0xFF6B7263)
}

@Composable
fun CourtsideTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = CS.Green,
            onPrimary = Color.White,
            secondary = CS.Green,
            background = CS.Background,
            onBackground = CS.Forest,
            surface = CS.Surface,
            onSurface = CS.Forest,
            surfaceVariant = CS.SurfaceLight,
            onSurfaceVariant = CS.Muted,
            outline = CS.Border,
            secondaryContainer = CS.Indicator,
            onSecondaryContainer = CS.Forest
        ),
        content = content
    )
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    padding: Dp = 15.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = CS.Surface,
        border = BorderStroke(1.dp, CS.Border.copy(alpha = 0.6f))
    ) {
        Column(Modifier.padding(padding), content = content)
    }
}
